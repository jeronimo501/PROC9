var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","c4e310e0-8174-4127-a46e-0cbcc94b488b","fb2cf37b-4045-44a6-b0b4-685ab60ca216","d666fd4c-baff-43eb-95ee-e9dc554211a0","e54fc538-90c9-4463-bcf4-538a1db65c85","c46b64b7-655d-45dc-b3e7-ffbcda42289b","62760337-2812-43cf-9364-5cab5f33b1df"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"1zzHTrlZ7OEjdkd3SaMYP5VMZ0C0Mh6X","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"vVMXwm50GiiQYcDDUbvGWQ5ZrvYA_.9c","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"fb2cf37b-4045-44a6-b0b4-685ab60ca216":{"sourceSize":{"x":640,"y":360},"frameSize":{"x":640,"y":360},"frameCount":1,"frameDelay":4,"name":"galaxy","sourceUrl":"assets/v3/animations/0BD_vw1A6MOTANIMUqdy3qKwGg5jJxQTy9LLDupI-Go/fb2cf37b-4045-44a6-b0b4-685ab60ca216.png","size":43339,"version":"koDwvef5xDCpkyyjd5jnfZqUORyMS0u1","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/v3/animations/0BD_vw1A6MOTANIMUqdy3qKwGg5jJxQTy9LLDupI-Go/fb2cf37b-4045-44a6-b0b4-685ab60ca216.png"},"d666fd4c-baff-43eb-95ee-e9dc554211a0":{"sourceSize":{"x":256,"y":256},"frameSize":{"x":256,"y":256},"frameCount":1,"frameDelay":4,"name":"hero1","sourceUrl":"assets/v3/animations/0BD_vw1A6MOTANIMUqdy3qKwGg5jJxQTy9LLDupI-Go/d666fd4c-baff-43eb-95ee-e9dc554211a0.png","size":64724,"version":"crjXVcnptEx9vhPqEHF9KbY8FnQwiLbo","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/v3/animations/0BD_vw1A6MOTANIMUqdy3qKwGg5jJxQTy9LLDupI-Go/d666fd4c-baff-43eb-95ee-e9dc554211a0.png"},"e54fc538-90c9-4463-bcf4-538a1db65c85":{"sourceSize":{"x":225,"y":225},"frameSize":{"x":225,"y":225},"frameCount":1,"frameDelay":12,"name":"enemy2","sourceUrl":null,"size":10075,"version":"MZqj6sBk4hDAO0SydKRczJ.OWQ4ooqQe","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/e54fc538-90c9-4463-bcf4-538a1db65c85.png"},"c46b64b7-655d-45dc-b3e7-ffbcda42289b":{"sourceSize":{"x":225,"y":225},"frameSize":{"x":225,"y":225},"frameCount":1,"frameDelay":12,"name":"enemy","sourceUrl":null,"size":12858,"version":"o3nTd0W4q.5M.nT1StzJTPnFXQg0c8vp","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/c46b64b7-655d-45dc-b3e7-ffbcda42289b.png"},"62760337-2812-43cf-9364-5cab5f33b1df":{"sourceSize":{"x":225,"y":70},"frameSize":{"x":225,"y":70},"frameCount":1,"frameDelay":12,"name":"enemy3","sourceUrl":null,"size":5016,"version":"zYn6Tqw3ICDqLuee6hHWXGMctdziSSEB","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/62760337-2812-43cf-9364-5cab5f33b1df.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b = createSprite(200,200);
 b.setAnimation("galaxy")
var hero = createSprite(200,345,200,345)
hero.shapeColor="red"

var enemy1 = createSprite(200,280,50,60)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,30,20)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,30,20)
enemy3.shapeColor="red"

var net = createSprite(200,5,200,20)
net.shapeColor="red"

var goal =0;
var death = 0

hero.setAnimation("hero1");
hero.scale=.2;
enemy1.setAnimation("enemy");
enemy1.scale=.1;
enemy2.setAnimation("enemy2");
enemy2.scale=.1;
enemy3.setAnimation("enemy3");
enemy3.scale=.1;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
  
//fondo(b);

createEdgeSprites()




enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Goals:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("death:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
